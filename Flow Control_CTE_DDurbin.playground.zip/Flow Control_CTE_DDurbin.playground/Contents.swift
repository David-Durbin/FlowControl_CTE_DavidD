//: Playground - noun: a place where people can play

import UIKit

//var str = "Hello, playground"

let temp1 = 80, temp2 = 50, temp3 = 32, precipitation: Bool = true  // hard code values for raining/snowing and temperatures
var testTemp = 42 // test value

print("We wish to welcome Sir to the AutoDress 3,000,000,000.")
print("The State of the Art in AutoDressing and Valet Software.")
print("") // blank line
print("Based on your local forecast, the temperature today should reach \(testTemp)  degrees today.")


if precipitation  // check to see if it is raining
{
    print("It is currently precipitating, and given the temperature, that likely means rain.")
}
else if precipitation && (testTemp <= temp3) // check to see if it is snowing
{
    print("It is currently precipitating, and given the temperature, that likely means snow.")
}
else  // it isn't raining or snowing
{
    print("It is not currently precipitating.")
}

// print recomendations
print("As such we would suggest that Sir select the following: ")
print("")

if testTemp >= temp1 // test for temp greater than or equal to 80 degrees
{
    print("A light sport shirt, prehpas in a light tan, some Chino shorts and deck shoes or sandels.")
    if  precipitation
    {
        print("Should Sir elect to venture outside, then a light coat would be in order to keep off the damp.")
    }
    print("Do not forget to collect your sunglasses before proceeding to the veranda Sir.")
} // end 80+ degree if
else if (testTemp < temp1) && (testTemp >= temp2) // temperature is between 80 degrees and 50 degrees
{
    print("A medium weight shirt, in a mild cream colour, with a set of charcoal gray Chino pants, and some Cole Haan")
    print("'Lewiston' Loafers would do Sir well in this weather.")
    if precipitation
    {
        print("Do not forget your Rodd & Gunn 'Armitage' Harrington Jacket Sir.")
    }
} // end 80 - 50 degree if
else if (testTemp < temp2) && (testTemp > temp3) // between 50 degrees and 32 degrees
{
    print("The Cutter & Buck Sport Shirt under the pale gray Half Zip Cashmere Pullover with")
    print("the 'Classic' Smartcare Relaxed Fit Cotton Pants and the tan 1901 Archer Buck shoes would do you well today Sir.")
    if precipitation
    {
        print("It would be advisable to collect the Filson 'Mile Marker' Waxed Coat from the cloak room before departing Sir.")
    }
} // end 50 - 32 degree if
else // 32 or colder
{
    print("If sir MUST depart, the Vince Camuto Merino Wool Turtleneck in the charcoal with the Santorelli Wool trousers, also in charcoal")
    print("and the UGG Neumel Chukka boots, black, naturally, and the Michael Kors Wool Double Breasted Peacoat should suffice to keep sir reasonably warm.")
    if precipitation // its snowing
    {
        print("The Polo Ralph Lauren Pajama pants and Pullover Hoodie with wool socks and UGG Ascot Leather Slippers are laid out for you Sir,")
        print("and a cup of hot apple cider with a shot of burbon are awaiting you in the great room where the butler has laid a superb fire of pine and apple wood.")
    }
} // end -32 if

print("")
print("Thank you again Sir for utilizing the AutoDress 3,000,000,000 and enjoy your day Sir.")

